import pickle


# load the model from disk
crf = pickle.load(open('crf_model.sav', 'rb'))


def features(sentence, index):
    """ sentence: [w1, w2, ...], index: the index of the word """
    return {
        'word': sentence[index],
        'is_first': index == 0,
        'is_last': index == len(sentence) - 1,
        'prefix-1': sentence[index][0],
        'suffix-1': sentence[index][-1],
        'prev_word1': '' if index == 0 else sentence[index - 1],
        'next_word1': '' if index == len(sentence) - 1 else sentence[index + 1],        
        'is_numeric': sentence[index].isdigit(),
    }


def pos_tag(sentence):
    sentence=sentence.split()
    sentence_features = [features(sentence, index) for index in range(len(sentence))]
    return list(zip(sentence, crf.predict([sentence_features])[0]))

