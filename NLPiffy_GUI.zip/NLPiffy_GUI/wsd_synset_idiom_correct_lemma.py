import pandas as pd
df = pd.read_csv("Talafeef.csv")

def wsd(sentence):
    wsd_list=[]
    tokens=sentence.split()
    for token in tokens:
        row=df[df['token']==token].head(1)
        if row.empty:
            x=(token,token)
            wsd_list.append(x)
        else:
            for idx, row in row.iterrows():
                if pd.isna(row['wsd']):
                    x=(token,token)
                else:
                    x=(token,row['wsd'])
                wsd_list.append(x)
    return(wsd_list)

def synset(sentence):
    synset_list=[]
    tokens=sentence.split()
    for token in tokens:
        rows=df[df['token']==token].head(1)
        if rows.empty:
            x=(token,token)
            synset_list.append(x)
        else:
            for idx, row in rows.iterrows():
                if pd.isna(row['synset']):
                    x=(token,token)
                else:
                    x=(token,row['synset'])
                synset_list.append(x)
    return synset_list

def idiom(sentence):
    idiom_list=[]
    tokens=sentence.split()
    for token in tokens:
        row=df[df['token']==token].head(1)
        if row.empty:
            x=(token,0)
            idiom_list.append(x)
        else:
            for idx, row in row.iterrows():
                if pd.isna(row['idiom']):
                    x=(token,0)
                else:
                    x=(token,row['idiom'])
                idiom_list.append(x)
    return idiom_list


def correct(sentence):
    correct_list=[]
    tokens=sentence.split()
    for token in tokens:
        row=df[df['token']==token].head(1)
        if row.empty:
            x=(token,token)
            correct_list.append(x)
        else:
            for idx, row in row.iterrows():
                if pd.isna(row['correct']):
                    x=(token,token)
                else:
                    x=(token,row['correct'])
                correct_list.append(x)
    return correct_list

def lemma(sentence):
    lemma_list=[]
    tokens=sentence.split()
    for token in tokens:
        rows=df[df['token']==token].head(1)
        if rows.empty:
            x=(token,token)
            lemma_list.append(x)
        else:
            for idx, row in rows.iterrows():
                if pd.isna(row['lemma']):
                    x=(token,token)
                else:
                    x=(token,row['lemma'])
                lemma_list.append(x)
    return lemma_list