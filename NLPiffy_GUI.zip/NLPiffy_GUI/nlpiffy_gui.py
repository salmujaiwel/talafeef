#Core Packages
import tkinter as tk
from tkinter import *
from tkinter import ttk
from tkinter.scrolledtext import *


#models files
from Skip_model import *
model_sg = torch.load(r"SkipGram_model.pt")
model_sg.eval()
embedding_in=model_sg.embedding_in
from crf_model import *
from ngram_model import *
from cbow_model import *
from wsd_synset_idiom_correct_lemma import *
from RNN_model import *
from BERT_model import *


#NLP Packages
#from textblob import TextBlob
#import spacy
#nlp = spacy.load('en_core_web_sm')
 
#Structure and Layout
window = Tk()
window.title("مشروع فريق تلافيف")
window.geometry("900x600")
window.minsize(900, 600)
window.config(background='black')

#TAB LAYOUT
tab_control = ttk.Notebook(window)
 
tab1 = ttk.Frame(tab_control)
tab2 = ttk.Frame(tab_control)
tab3 = ttk.Frame(tab_control)

#ADD TABS TO NOTEBOOK
tab_control.add(tab1, text='المعجّم العربي')
tab_control.add(tab2, text='معالجة الملفات')
tab_control.add(tab3, text='فريق المشروع')


label1 = Label(tab1, text= '   ',padx=5, pady=5)
label1.grid(column=0, row=0)
 
label2 = Label(tab2, text= 'معالجة الملفات',padx=5, pady=5)
label2.grid(column=1, row=0,columnspan=2)

label3 = Label(tab3, text= 'حول البرنامج',padx=5, pady=5)
label3.grid(column=0, row=0)

tab_control.pack(expand=1, fill='both')

about_label = Label(tab3,text="أعضاء الفريق: د. سلطان المجيول؛ باسم عصام الدين عمر؛ حمدي هبوزا؛ مريم الشهري\n ",pady=5,padx=5)
about_label.grid(column=0,row=1)

#Functions FOR NLP FOR TAB ONE
def get_tokens():
	raw_text = str(raw_entry.get())
	final_text = list(raw_text.split(" "))
	result = '\nToken:{}'.format(final_text)
	tab1_display.insert(tk.END,result)

#crf model
def get_pos_tags():
	raw_text = str(raw_entry.get())
	final_text = pos_tag(raw_text)
	result = '\nPOS:{}'.format(final_text)
	tab1_display.insert(tk.END,result)

#Skipgram
def get_skipgram():
	raw_text = str(raw_entry.get())
	for token in list(raw_text.split(" ")):	
		final_text = get_related_sg(token, embedding_in, vocab)
		result = '\nSkipGram:{}'.format(final_text)
		tab1_display.insert(tk.END,result)
#CBOW
def get_cbow():
	raw_text = str(raw_entry.get())
	for token in list(raw_text.split(" ")):	
		final_text = get_related_cbow(token)
		result = '\nCBOW:{}'.format(final_text)
		tab1_display.insert(tk.END,result)

#ngram model
def get_ngram():
	raw_text = str(raw_entry.get())
	#nbr_grams = int(n_gr.get())
	#m = create_ngram_model(nbr_grams, r"Dataset-UFT16.txt")
	#random.seed(7)
	result = '\n'+'الكلمة المقترحة > '+ ngram_predict(raw_text)
	tab1_display.insert(tk.END,result)

#wsd
def get_wsd():
	raw_text = str(raw_entry.get())
	result = '\nDefinition{}'.format(wsd(raw_text))
	tab1_display.insert(tk.END,result)

#synset
def get_synset():
	raw_text = str(raw_entry.get())
	result = '\nSynset{}'.format(synset(raw_text))
	tab1_display.insert(tk.END,result)

#idiom
def get_idiom():
	raw_text = str(raw_entry.get())
	result = '\nIdioms:{}'.format(idiom(raw_text))
	tab1_display.insert(tk.END,result)

#correct
def get_correct():
	raw_text = str(raw_entry.get())
	result = '\nCorrection{}'.format(correct(raw_text))
	tab1_display.insert(tk.END,result)

#lemma
def get_lemma():
	raw_text = str(raw_entry.get())
	result = '\nLemmas:{}'.format(lemma(raw_text))
	tab1_display.insert(tk.END,result)

#verbal_associat_rnn
def verbal_associat_rnn():
	raw_text = str(raw_entry.get())
	final_text= raw_text  +' '+ngram_predict(raw_text)
	result = '\nRNN:{}'.format(pos_rnn(final_text))
	tab1_display.insert(tk.END,result)

#verbal_associat_crf
def verbal_associat_crf():
	raw_text = str(raw_entry.get())
	final_text=  raw_text  +' '+ ngram_predict(raw_text)
	result = '\nCRF:{}'.format(pos_tag(final_text))
	tab1_display.insert(tk.END,result)

def get_bert():
	raw_text = str(raw_entry.get())
	for token in list(raw_text.split(" ")):	
		final_text = get_related_bert(token)
		result = '\nBERT:{}'.format(final_text)
		tab1_display.insert(tk.END,result)

#Clear entry widget
def clear_entry_text():
	entry1.delete(0,END)

def clear_display_result():
	tab1_display.delete('1.0',END)


#Clear Text  with position 1.0
def clear_text_file():
	displayed_file.delete('1.0',END)

#Clear Result of Functions
def clear_result():
	tab2_display_text.delete('1.0',END)

#Functions for TAB 2 FILE PROCESSER
#Open File to Read and Process
def openfiles():
	file1 = tk.filedialog.askopenfilename(filetypes=(("Text Files",".txt"),("All files","*")))
	read_text = open(file1, encoding = "UTF-16").read()
	displayed_file.insert(tk.END,read_text)


def get_file_tokens():
	raw_text = displayed_file.get('1.0',tk.END)
	final_text = list(raw_text.split(" "))
	result = '\nTokens:{}'.format(final_text)
	tab2_display_text.insert(tk.END,result)

#crf model file
def get_file_pos_tags():
	raw_text = displayed_file.get('1.0',tk.END)
	final_text = pos_tag(raw_text)
	result = '\nPOS:{}'.format(final_text)
	tab2_display_text.insert(tk.END,result)

#Skipgram file
def get_file_skipgram():
	raw_text = displayed_file.get('1.0',tk.END)
	for token in list(raw_text.split(" ")):	
		final_text = get_related_sg(token, embedding_in, vocab)
		result = '\nRelated words using SG:{}'.format(final_text)
		tab2_display_text.insert(tk.END,result)

#CBOW file
def get_file_cbow():
	raw_text = displayed_file.get('1.0',tk.END)
	for token in list(raw_text.split(" ")):	
		final_text = get_related_cbow(token)
		result = '\nRelated words using CBOW:{}'.format(final_text)
		tab2_display_text.insert(tk.END,result)

#ngram model
def ngram_file():
	raw_text = displayed_file.get('1.0',tk.END)
	#nbr_grams_file = int(n_gr_file.get())
	#m = create_ngram_model(nbr_grams_file, r"Talafeef--Seg.txt")
	#random.seed(7)
	result = '\n'+'الكلمة المقترحة > '+ ngram_predict(raw_text)
	tab2_display_text.insert(tk.END,result)

#wsd
def get_file_wsd():
	raw_text = displayed_file.get('1.0',tk.END)
	result = '\nwsd:{}'.format(wsd(raw_text))
	tab2_display_text.insert(tk.END,result)

#synset
def get_file_synset():
	raw_text = displayed_file.get('1.0',tk.END)
	result = '\nsynset:{}'.format(synset(raw_text))
	tab2_display_text.insert(tk.END,result)

#idiom
def get_file_idiom():
	raw_text = displayed_file.get('1.0',tk.END)
	result = '\nidiom:{}'.format(idiom(raw_text))
	tab2_display_text.insert(tk.END,result)

#correct
def get_file_correct():
	raw_text = displayed_file.get('1.0',tk.END)
	result = '\ncorrect:{}'.format(correct(raw_text))
	tab2_display_text.insert(tk.END,result)

#lemma
def get_file_lemma():
	raw_text = displayed_file.get('1.0',tk.END)
	result = '\nlemmatizer:{}'.format(lemma(raw_text))
	tab2_display_text.insert(tk.END,result)

#ngram + rnn
def verbal_associat_rnn_file():
	raw_text = displayed_file.get('1.0',tk.END)
	final_text= raw_text  +' '+ ngram_predict(raw_text)
	result = '\nVerbal association RNN:{}'.format(pos_rnn(final_text))
	tab2_display_text.insert(tk.END,result)

#n-gram + crf
def verbal_associat_crf_file():
	raw_text = displayed_file.get('1.0',tk.END)
	final_text= raw_text  +' '+ ngram_predict(raw_text)
	result = '\nVerbal association RNN:{}'.format(pos_tag(final_text))
	tab2_display_text.insert(tk.END,result)

#BERT file
def get_file_bert():
	raw_text = displayed_file.get('1.0',tk.END)
	raw_text = raw_text.strip('\n')
	raw_text = raw_text.strip(' ')
	tokens = list(raw_text.split(" "))
	# tkns=tokens[1:-1]
	for token in tokens :	
		final_text = get_related_bert(token)
		result = '\nRelated words using BERT:{}'.format(token,final_text)
		tab2_display_text.insert(tk.END,result)

#MAIN NLP TAB
l1=Label(tab1,text="أدخل النص للتحليل")
l1.grid(row=1,column=3,sticky='nwse')

raw_entry=StringVar()
entry1=Entry(tab1,textvariable=raw_entry,width=60)
entry1.grid(row=1,column=1,columnspan=2,sticky='nwse')

#bUTTONS

#extra tab1
#synset
button7=Button(tab1,text="المترادفات", width=22,height=2 ,command=get_synset,bg="#b9f6ca")
button7.grid(row=3,column=0,padx=10,pady=10)

#idiom
button8=Button(tab1,text="التعبير الاصطلاحي", width=22,height=2 ,command=get_idiom,bg="#b9f6ca")
button8.grid(row=3,column=1,padx=10,pady=10)

#correct
button9=Button(tab1,text="التصحيح", width=22,height=2 ,command=get_correct,bg="#b9f6ca")
button9.grid(row=3,column=2,padx=10,pady=10)

#wsd
button10=Button(tab1,text="التعريف", width=22,height=2 ,command=get_wsd,bg="#b9f6ca")
button10.grid(row=3,column=3,padx=10,pady=10)

#Tokenize
button1=Button(tab1,text="التفريق", width=22,height=2 ,command=get_tokens,bg='#b9f6ca')
button1.grid(row=4,column=0,padx=10,pady=10)

#POS Tags
button2=Button(tab1,text="الوسم النحوي ", width=22,height=2 ,command=get_pos_tags,bg='#b9f6ca')
button2.grid(row=4,column=1,padx=10,pady=10)

#skipgram
button3=Button(tab1,text="التنبؤ بسياق الكلمات ", width=22,height=2 ,command=get_skipgram,bg='#b9f6ca')
button3.grid(row=4,column=2,padx=10,pady=10)

#CBOW
button4=Button(tab1,text="التنبؤ بالكلمات السياقية ", width=22,height=2 ,command=get_cbow,bg='#b9f6ca')
button4.grid(row=4,column=3,padx=10,pady=10)

#Ngram
button5=Button(tab1,text="التصاحب اللفظي", width=22,height=2 ,command=get_ngram,bg="#b9f6ca")
button5.grid(row=5,column=0,padx=10,pady=10)

#Ngram + RNN
button6=Button(tab1,text="RNN التلازم اللفظي", width=22,height=2 ,command=verbal_associat_rnn,bg="#b9f6ca")
button6.grid(row=5,column=1,padx=10,pady=10)

#Ngram + CRF
button11=Button(tab1,text="CRF التلازم اللفظي", width=22,height=2 ,command=verbal_associat_crf,bg="#b9f6ca")
button11.grid(row=5,column=2,padx=10,pady=10)
#n_gr=StringVar()
#entry2=Entry(tab1,textvariable=n_gr,width=12,font=('Arial', 17))
#entry2.grid(row=5,column=1,padx=10,pady=10)

#Ngram
button12=Button(tab1,text="الأصل المعجمي", width=22,height=2 ,command=get_lemma,bg="#b9f6ca")
button12.grid(row=5,column=3,padx=10,pady=10)

#BERT
button15=Button(tab1,text="BERT التنبؤ بالسياق النصي ", width=22,height=2 ,command=get_bert,bg="#b9f6ca")
button15.grid(row=6,column=1,padx=10,pady=10)

#Reset
button13=Button(tab1,text="إعادة تعيين", width=22,height=2 ,command=clear_entry_text,bg="#b9f6ca")
button13.grid(row=6,column=2,padx=10,pady=10)

#Clear Result
button14=Button(tab1,text="مسح النتيجة", width=22,height=2 ,command=clear_display_result,bg='#b9f6ca')
button14.grid(row=6,column=3,padx=10,pady=10)

#Display Screen For Result
tab1_display = Text(tab1,height=18)
tab1_display.grid(row=7,column=0, columnspan=4,padx=5,pady=5,sticky='nwse')

#Allows you to edit
tab1_display.config(state=NORMAL)

#FILE READING  AND PROCESSING TAB

#l1=Label(tab2,text="فتح ملف للمعالجة")
#l1.grid(row=1,column=1,columnspan=2)

displayed_file = ScrolledText(tab2,height=6)# Initial was Text(tab2)
displayed_file.grid(row=2,column=0,columnspan=4,padx=5,pady=3,sticky='nwse')

#BUTTONS FOR SECOND TAB/FILE READING TAB

#extra tab2
# synset
b7=Button(tab2,text="المترادفات", width=22,height=2 ,command=get_file_synset,bg="#b9f6ca")
b7.grid(row=3,column=0,padx=10,pady=10)

#idiom
b8=Button(tab2,text="التعبير الاصطلاحي", width=22,height=2 ,command=get_file_idiom,bg="#b9f6ca")
b8.grid(row=3,column=1,padx=10,pady=10)

#correct
b9=Button(tab2,text="التصحيح", width=22,height=2 ,command=get_file_correct,bg="#b9f6ca")
b9.grid(row=3,column=2,padx=10,pady=10)

#wsd
b10=Button(tab2,text="التعريف", width=22,height=2 ,command=get_file_wsd,bg="#b9f6ca")
b10.grid(row=3,column=3,padx=10,pady=10)

b2=Button(tab2,text="التفريق", width=22,height=2,command=get_file_tokens,bg='#b9f6ca')
b2.grid(row=4,column=0,padx=10,pady=10)

b3=Button(tab2,text="الوسم النحوي", width=22,height=2,command=get_file_pos_tags,bg='#b9f6ca')
b3.grid(row=4,column=1,padx=10,pady=10)

b4=Button(tab2,text="التنبؤ بسياق الكلمات ", width=22,height=2,command=get_file_skipgram,bg='#b9f6ca')
b4.grid(row=4,column=2,padx=10,pady=10)

b5=Button(tab2,text="التنبؤ بالكلمات السياقية ", width=22,height=2,command=get_file_cbow,bg='#b9f6ca')
b5.grid(row=4,column=3,padx=10,pady=10)

b11=Button(tab2,text="التصاحب اللفظي", width=22,height=2,command=ngram_file,bg="#b9f6ca")
b11.grid(row=5,column=0,padx=10,pady=10)

b6=Button(tab2,text="RNN التلازم اللفظي", width=22,height=2,command=verbal_associat_rnn_file,bg="#b9f6ca")
b6.grid(row=5,column=1,padx=10,pady=10)

b10=Button(tab2,text="CRF التلازم اللفظي", width=22,height=2,command=verbal_associat_crf_file,bg="#b9f6ca")
b10.grid(row=5,column=2,padx=10,pady=10)

b7=Button(tab2,text="الأصل المعجمي", width=22,height=2,command=get_file_lemma,bg="#b9f6ca")
b7.grid(row=5,column=3,padx=10,pady=10)

#n_gr_file=StringVar()
#entry3=Entry(tab2,textvariable=n_gr_file,width=12,font=('Arial', 17))
#entry3.grid(row=5,column=1)

b12=Button(tab2,text="BERT التنبؤ بالسياق النصي ", width=22,height=2,command=get_file_bert,bg='#b9f6ca')
b12.grid(row=6,column=0,padx=10,pady=10)

b8=Button(tab2,text="إعادة تعيين", width=22,height=2,command=clear_text_file,bg="#b9f6ca")
b8.grid(row=6,column=2,padx=10,pady=10)

b0=Button(tab2,text="افتح ملف", width=22,height=2,command=openfiles,bg='#b9f6ca')
b0.grid(row=6,column=1,padx=10,pady=10)

b9=Button(tab2,text="مسح النتيجة", width=22,height=2,command=clear_result,bg='#b9f6ca')
b9.grid(row=6,column=3,padx=10,pady=10)

#Display Screen

#tab2_display_text = Text(tab2)
tab2_display_text = ScrolledText(tab2,height=18)
tab2_display_text.grid(row=7,column=0, columnspan=4,padx=5,pady=5,sticky='nwse')

#Allows you to edit
tab2_display_text.config(state=NORMAL)

n_rows =7
n_columns =4
for i in range(n_rows):
    tab1.grid_rowconfigure(i,  weight =1)
for i in range(n_columns):
    tab1.grid_columnconfigure(i,  weight =1,uniform='first')


for i in range(n_rows):
    tab2.grid_rowconfigure(i,  weight =1)
for i in range(n_columns):
    tab2.grid_columnconfigure(i,  weight =1,uniform='second')


window.mainloop()