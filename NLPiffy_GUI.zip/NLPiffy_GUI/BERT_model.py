from collections import Counter
import numpy as np
from numpy import load 
import pickle


data= load(r'token_vecs_cat_array.npz')
token_vecs_cat_array = data['arr_0']  


open_file = open(r'tokenized_text.pkl', "rb")
tokenized_text = pickle.load(open_file)
open_file.close()

def get_related_bert(token: str, num_synonyms: int = 10):
    """Given a token, return a list of top N most similar words to the token."""
    if token not in tokenized_text:
        return [] 
    idx=tokenized_text.index(token)
    if idx>len(token_vecs_cat_array):
        return []
    token_vec = token_vecs_cat_array[idx]
    sims = Counter()

    for i in range (512):
        sim = np.dot(token_vec, token_vecs_cat_array[i])/(np.linalg.norm(token_vec) * np.linalg.norm(token_vecs_cat_array[i]))
        sims[tokenized_text[i]] = sim

    return sims.most_common(num_synonyms)