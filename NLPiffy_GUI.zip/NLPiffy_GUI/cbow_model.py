import numpy as np
from collections import Counter
# from keras.preprocessing.sequence  pad_sequences


#load model
w2v_my = np.load('CBOW_Embeddings.npz')


def get_related_cbow(token: str, num_synonyms: int = 10):
    """Given a token, return a list of top N most similar words to the token."""
    if (token in w2v_my):
        token_vec = w2v_my[token]
        sims = Counter()

        for w,vec in w2v_my.items():
            sim = np.dot(token_vec, vec)/(np.linalg.norm(token_vec) * np.linalg.norm(vec))
            sims[w] = sim

        return sims.most_common(num_synonyms)
    else :
        return []