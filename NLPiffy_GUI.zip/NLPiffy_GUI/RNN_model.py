#from keras.utils import pad_sequences
#from keras.preprocessing.sequence import pad_sequences
try:
    from keras.utils import pad_sequences
except ImportError:
    from keras.preprocessing.sequence import pad_sequences
from keras import backend as K
from tensorflow import keras
import pickle
import numpy as np

def ignore_class_accuracy(to_ignore=0):
    def ignore_accuracy(y_true, y_pred):
        y_true_class = K.argmax(y_true, axis=-1)
        y_pred_class = K.argmax(y_pred, axis=-1)
 
        ignore_mask = K.cast(K.not_equal(y_pred_class, to_ignore), 'int32')
        matches = K.cast(K.equal(y_true_class, y_pred_class), 'int32') * ignore_mask
        accuracy = K.sum(matches) / K.maximum(K.sum(ignore_mask), 1)
        return accuracy
    return ignore_accuracy


#load the model, word2index and tag2index lists
model_path='RNN_model.h5'
model = keras.models.load_model(model_path, custom_objects={"ignore_accuracy": ignore_class_accuracy })

word2index_file = open("RNN_word2index.pkl", "rb")
word2index = pickle.load(word2index_file)

tag2index_file = open("RNN_tag2index.pkl", "rb")
tag2index = pickle.load(tag2index_file)

def to_categorical(sequences, categories):
    cat_sequences = []
    for s in sequences:
        cats = []
        for item in s:
            cats.append(np.zeros(categories))
            cats[-1][item] = 1.0
        cat_sequences.append(cats)
    return np.array(cat_sequences)

def logits_to_tokens(sequences, index):
    token_sequences = []
    for categorical_sequence in sequences:
        token_sequence = []
        for categorical in categorical_sequence:
            token_sequence.append(index[np.argmax(categorical)])
 
        token_sequences.append(token_sequence)
 
    return token_sequences

#used to remove '-PAD-' elements from resulting final list
def unppad(L):
    for i in range(len(L)):
        if L[-i-1]!='-PAD-':
            index=-i-1
            return L[0:index+1]
        else:
            continue

def pos_rnn(sentence):
    MAX_LENGTH = 2328
    test_samples = [sentence.split()]
    if len(test_samples)>MAX_LENGTH:
        test_samples=test_samples[0:MAX_LENGTH-1]
    test_samples_X = []
    
    for s in test_samples:
        s_int = []
        for w in s:
            try:
                s_int.append(word2index[w.lower()])
            except KeyError:
                s_int.append(word2index['-OOV-'])
        test_samples_X.append(s_int)
    test_samples_X = pad_sequences(test_samples_X, maxlen=MAX_LENGTH, padding='post')
    predictions = model.predict(test_samples_X)
    results=logits_to_tokens(predictions, {i: t for t, i in tag2index.items()})[0]
    unppad_results = unppad(logits_to_tokens(predictions, {i: t for t, i in tag2index.items()})[0])
    a_zip = zip(sentence.split(), unppad_results) 
    return list(a_zip) 

